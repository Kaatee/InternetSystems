package app;

public class Constants {
    public static final String RESULT_NOT_FOUND = "Result not found";
    public static final String APPLICATION_XML = "application/xml";
    public static final String APPLICATION_JSON = "application/json";
    public static final String PLAIN_TEXT = "text/plain";
    public static final String DELETED_SUCCESSFULY = "Deleted succesfully";
    public static final String ADDED_SUCCESSFULY = "Added succesfully";
    public static final String EDITED_SUCCESSFULY = "Edited succesfully";

}
